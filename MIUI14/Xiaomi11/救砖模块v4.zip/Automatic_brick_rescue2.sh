#!/system/bin/sh
#本脚本由搞机助手自动创建
#作者：by：Han | 情非得已c
#请不要试图篡改本脚本，否则一切后果自负，已安装版本：v2021041500(35)
#特别鸣谢Magisk提供服务支持：by topjohnwu


Disable_All_Modules() {
    ls "/data/adb/modules" | while read i; do
        [[ "$i" = "$MODID" ]] && continue
        touch "/data/adb/modules/$i/disable" &>/dev/null
    done
    reboot
}

Statistics() {
    if [[ ! -f $LOG ]]; then
        echo "1" >$LOG
    else
        Number_of_brick_rescue=`cat $LOG`
        p="$(expr $Number_of_brick_rescue + 1)"
        echo "$p" >$LOG
    fi
}


MODDIR=${0%/*}
MODID=${MODDIR##*/}
Module_XinXi=$MODDIR/module.prop
START_LOG=$MODDIR/Number_of_starts.log
LOG=$MODDIR/Number_of_brick_rescue.log
VERSION=$MODDIR/now_version
now_version=$(getprop ro.system.build.version.incremental)


    mv -f $Module_XinXi.bak $Module_XinXi && sed -i '34d' "$0"

#这里下面最后“1.5”就是正常救砖时延迟的时间
        sleep 1.5m

        if [[ `getprop init.svc.bootanim` = "stopped" ]]; then
        rm -f "$START_LOG"

        if [[ -f $LOG ]]; then
            Number_of_brick_rescue=`cat $LOG`
            sed -i "/^description=/c description=自动救砖条件：系统连续重启到3次或卡在开机界面1.5分钟(每次升级系统时将自动延长时间至6分钟)，将禁用所有模块。若再不开机会执行APP解冻救砖模式再开机，已为您自动救砖：$Number_of_brick_rescue次。" "$Module_XinXi"
        echo "$now_version" > "$VERSION"   
        fi
    else
        Statistics
        Disable_All_Modules
    fi

